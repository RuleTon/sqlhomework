create definer = root@localhost trigger bonusadd
    after insert
    on employees
    for each row
    call bonussalaries(NEW,emp_no,2000);

