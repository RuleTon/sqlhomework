create
    definer = root@localhost function manager(firstName char(15), lastName char(25)) returns varchar(20)
begin

return ( select dept_manager.emp_no
FROM
dept_manager
join
employees on dept_manager.emp_no = employees.emp_no
join
departments on dept_manager.dept_no = departments.dept_no
where first_name = firstName and last_name = lastName);
end;

